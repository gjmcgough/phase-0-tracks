

class Spaceship
	attr_reader :max_speed
	attr_accessor :ship_name

	def initialize(ship_name, max_speed)
		@ship_name = ship_name
		@max_speed = max_speed
		@location = "Launch Site"
		@inventory = {}
	end

	def enable_shield
		"*woooomp* #{@ship_name} Shield engaged!"
	end

	def disable_shield
		"*wooomp* #{@ship_name} Shield disengaged!"
	end

	def warp_to(location)
		@location = location
		"Traveling at #{@max_speed} to #{@location}."
	end

	def find_string_integer_total(item)
		total_int_value_for_string = 0
		item.split('').each do |letter|
			total_int_value_for_string += letter.ord
		end
		total_int_value_for_string
	end

	def tractor_beam(item)
		disable_shield
		if find_string_integer_total(item) < 500
			@inventory[item] = @location
			enable_shield
			return true
		else
			puts "#{item} too heavey to beam."
			return false
		end
	end

	def pickup(item_location, item_description)
		warp_to(item_location)
		tractor_beam(item_description)
	end

	def print_inventory
		@inventory.each do |item, location|
			puts "#{item} was picked up in #{location}."
		end
		@inventory
	end

	def cargo_weight
		items_total_value = 0
		@inventory.each do |item, location|
			items_total_value += find_string_integer_total(item)
		end
		items_total_value
	end

end


new_ship = Spaceship.new('USS Enterprise', 200000)
new_ship_2 = Spaceship.new('HMS Andromeda', 108277)
# p new_ship
# p new_ship_2
# new_ship.ship_name = 'USS Trump'
# p new_ship
# puts "andrmeda is travelling at #{new_ship_2.max_speed}"
# new_ship.enable_shield
# new_ship_2.disable_shield
# new_ship_2.warp_to("Uranus")
# new_ship_2.warp_to("afghanistan")
# new_ship_2.tractor_beam('cow')
# new_ship_2.tractor_beam('owc')
# new_ship_2.tractor_beam('woc')
# new_ship_2.print_inventory
# # p new_ship_2.cargo_weight
# p new_ship.pickup("Zimbabwe", "Lion")
# p new_ship.print_inventory
# p new_ship
# p new_ship_2
# COMMENTS

#  I was confused with question 7 initially because I thought the string 'cow' was supposed to equate to 329 because it seemed in the explanation that the total was for the string. question 10 cleared up the misunderstanding for me and I corrected it by creating a new method to determine a strings total integer value.  Just thought I'd mention it, because it was kind of confusing. Have a great day and please send me onto campus!!! :D