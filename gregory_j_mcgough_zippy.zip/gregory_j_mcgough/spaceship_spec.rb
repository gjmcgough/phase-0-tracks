require_relative 'spaceship'

describe Spaceship do
	let(:ship) {Spaceship.new('USS Enterprise', 200000)}

	it "enables the ship's shield" do
		expect(ship.enable_shield).to eq "*woooomp* USS Enterprise Shield engaged!" 
	end

	it "disables the ships shield" do
		expect(ship.disable_shield).to eq "*wooomp* USS Enterprise Shield disengaged!" 
	end

	it "warps the ship to a new location at max speed" do
		expect(ship.warp_to('Uzbekistan')).to eq "Traveling at 200000 to Uzbekistan."
	end

	it "finds the total integer amount for a string" do
		expect(ship.find_string_integer_total('cow')).to eq 329
	end

	it "disables shields beams an item up if it weighs less than 500 and saves its location, then disables shield" do
		expect(ship.tractor_beam('cow')).to eq true
	end

	it "warps to a location and beams up an item" do
		expect(ship.pickup('Mars', 'cow')).to eq true
	end
	
end